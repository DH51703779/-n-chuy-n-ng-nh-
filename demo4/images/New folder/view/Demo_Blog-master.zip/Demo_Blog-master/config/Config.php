<?php

	$con = mysqli_connect("localhost","root","","blog") or die("Can not connect to MySQL");
	mysqli_set_charset($con,"UTF8");

 ?>