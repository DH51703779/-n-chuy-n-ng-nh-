<?php
$conn = new PDO('mysql:host=localhost;dbname=bookstore_vn', 'root', '');